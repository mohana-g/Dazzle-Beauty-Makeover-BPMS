<?php

	include('connection.php');
	$user_name = $_POST['u_name'];
	$query = "UPDATE admin SET logout_time = CURRENT_TIMESTAMP WHERE a_name = '$user_name'";
	$res = mysqli_query($con,$query);

?>