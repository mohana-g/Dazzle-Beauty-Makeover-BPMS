<?php
	$p = $_POST["submit"];
	$name = $_POST["sname"];
	$dur = $_POST["sdur"];
	$amt = $_POST["samt"];
	$sts = $_POST["ssts"];
	include('connection.php');
	$query = "UPDATE service SET ser_name='$name',ser_amt='$amt',ser_dur='$dur',ser_sts='$sts' WHERE ser_name='$name'";
	$res =mysqli_query($con,$query);
	if($res){
		header('location:services.php?page='.$p.'');
	}
	else{
		echo "Error";
	}
?>