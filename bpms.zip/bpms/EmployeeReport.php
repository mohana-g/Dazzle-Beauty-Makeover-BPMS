<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Welcome To | Dazzle Beauty Makeover </title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />
	
	<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
	
	<!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>
	
	<!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />
	
	<!-- Bootstrap DatePicker Css -->
    <link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" />
	
	<!-- Bootstrap Select Css -->
    <link href="plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
	
	<!--<script src="CSVExport.js"></script>-->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.debug.js"></script>
	
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
	
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.min.js"></script>
	
	<script>
	function generatePDF(){
		const element = document.getElementById("export");
		html2pdf()
		.from(element)
		.save()
	}
	/*const datatable=document.getElementById("datatable");
		const CSVbutton=document.getElementById("CSVbutton");
		 CSVbutton.addEventListener("click",() => {
			 const exporter = new CSVExport(datatable,false);
			 const csvOutput = exporter.convertToCSV();
			 const csvBlob=new Blob([csvOutput],{type:"text/csv"});
			 const bloburl = URL.createObjectURL(csvBlob);
			 const anchorElement = document.createElement("a");
			 
			 anchorElement.href=bloburl;
			 anchorElement.download="employee.csv";
			 anchorElement.click();
			 
			 setTimeout(()=>{
				 URL.revokeObjectURL(bloburl);
			 }, 500);
		 });
		*/
	/*function htmlToCSV(html,filename){
		var data=[];
		var rows=document.querySelectorAll("table tr");
		
		for(var i=0;i<rows.length;i++){
			var row = [],cols=rows[i].querySelectorAll("td, th");
			
			for(var j=0;j<cols.length;j++){
				rows.push(cols[j].innerText);
			}
			data.push(row.join(","));
		}
		downloadCSVFile(data.join("\n"),filename);
	}
	function downloadCSVFile(csv,filename){
		var csv_file,download_link;
		
		csv_file=new Blob([csv],{type:"text/csv"});
		
		download_link=document.createElement("a");
		download_link.download=filename;
		download_link.href=window.URL.createObjectURL(csv_file);
		download_link.style.display="none";
		document.body.appendChild(download_link);
		download_link.click();
	}
	document.getElementById("CSVbutton").addEventListener("click",function(){
		var html=document.querySelector("table").outerHTML;
		htmlToCSV(html,"Users.csv");
	});*/
	</script>
</head>

<body class="theme-purple">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="index.html">Dazzle Beauty Makeover - Parlour Management</a>
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>
                    <li><a href="home.php"><i class="material-icons">home</i><span>Home</span></a></li>
                    <li><a href="appointments.php"><i class="material-icons">event</i><span>Appointments</span></a></li>
                    <li><a href="services.php"><i class="material-icons">menu</i><span>Services</span></a></li>
                    <li><a href="employee.php"><i class="material-icons">face</i><span>Employee</span></a></li>
					<li><a href="customer.php"><i class="material-icons">people</i><span>Customer</span></a></li>
					<li><a href="#" class="menu-toggle"><i class="material-icons">report</i><span>Reports</span></a>
						<ul class="ml-menu">
						<li><a href="AppointmentsReport.php">Appointments</a></li>
						<li><a href="ServiceReport.php">Services</a></li>	
						<li><a href="EmployeeReport.php">Employees</a></li>	
						<li><a href="CustomerReport.php">Customer</a></li>
						</ul>
					</li>
                </ul>
            </div>
            <!-- #Menu -->
            
        </aside>
        <!-- #END# Left Sidebar -->
    </section>
	
	<div class="modal fade" id="addnew-modalp" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="addnew-modalLabel">Profile</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cname">Name</label>
                                            <input type="text" class="form-control" name="cname" value="<?php echo $ares["a_name"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmail">Email</label>
                                            <input type="text" class="form-control" name="cmail" value="<?php echo $ares["a_mail"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmob">Mobile</label>
                                            <input type="text" class="form-control" name="cmob" value="<?php echo $ares["a_mob"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="camob">Address</label>
                                            <input type="text" class="form-control" name="camob" value="<?php echo $ares["a_add"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" name="submit" value="<?php echo $page?>" data-toggle="modal" data-target="#addnew-modalp1">EDIT</button>
                            <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">CANCEL</button>
                        </div>
                    </div>
                </div>
            </div>
	
			<div class="modal fade" id="addnew-modalp1" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
						<form action="updateadminemp.php" method="post">
                        <div class="modal-header">
                            <h4 class="modal-title" id="addnew-modalLabel">Edit Profile</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_name">Name</label>
                                            <input type="text" class="form-control" name="a_name" value="<?php echo $ares["a_name"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_mail">Email</label>
                                            <input type="text" class="form-control" name="a_mail" value="<?php echo $ares["a_mail"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_mob">Mobile</label>
                                            <input type="text" class="form-control" name="a_mob" value="<?php echo $ares["a_mob"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_add">Address</label>
                                            <input type="text" class="form-control" name="a_add" value="<?php echo $ares["a_add"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_pass">Password</label>
                                            <input type="password" class="form-control" name="a_pass" required/>
                                        </div>
                                    </div>
								</div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" value="<?php echo $ares["a_pass"]; ?>" name="submit">UPDATE</button>
                            <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">CANCEL</button>
                        </div>
						</form>
                    </div>
                </div>
            </div>
	
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>EMPLOYEES</h2>
            </div>            
            <!-- Striped Rows -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>EMPLOYEES</h2>
                        </div>
						<form action="" method="POST">
							<div class="row m-t-20 m-l-10">
								<div class="col-lg-1">
									<input type="button" class="btn btn-primary waves-effect" name="from" value="FROM">
								</div>
								<div class="col-lg-4">
									<input type="datetime-local" class="form-control m-l-0" name="date_from">
								</div>
								<div class="col-lg-1"></div>
									<div class="col-lg-1">
										<input type="button" class="btn btn-primary waves-effect" name="to" value="TO">
									</div>
									<div class="col-lg-4">
										<input type="datetime-local" class="form-control m-l-0" name="date_to">
									</div>
							</div>
							<div class="row m-t-20 m-l-10">
								<div class="col-lg-3">
									<input type="text" class="form-control m-l-10" name="e_name" placeholder="Enter name">
								</div>
								<div class="col-lg-3">
									<input type="text" class="form-control m-l-10" name="e_email" placeholder="Enter email ID">
								</div>
								<div class="col-lg-3">
									<input type="text" class="form-control m-l-10" name="e_spec" placeholder="Enter Specialist In">
								</div>
								<div class="col-lg-2 align-right">
									<button type="submit" class="btn btn-primary waves-effect" name="filter">FILTER</button>
								</div>
							</div>
						</form>
						<div id="export">
                        <div class="body table-responsive">
								<?php
								$user="root";
								$host="localhost";
								$pass="";
								$db="bpms";
								$dbcon=mysqli_connect($host,$user,$pass,$db);
								if(isset($_POST['filter'])){
												//Name , email , specialist , from and to
												if(empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$query="SELECT * FROM `employee`";
												}
												else if(!empty($_POST['e_email']) && !empty($_POST['date_from']) && !empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$to=$_POST['date_to'];
													$name=$_POST['e_name'];
													$email=$_POST['e_email'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_email`='$email' AND `e_spec`='$spec' AND `e_date` BETWEEN '$from' AND '$to'";
												}
									
												//Name
												else if(empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$name=$_POST['e_name'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name'";
												}
									
												//Email
												else if(!empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$email=$_POST['e_email'];
													$query="SELECT * FROM `employee` WHERE `e_email`='$email'";
												}
									
												//Specialist
												else if(empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_spec`='$spec'";
												}
												
												//Name and email
												else if(!empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$name=$_POST['e_name'];
													$email=$_POST['e_email'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_email`='$email'";
												}
									
												//Name and specialist
												else if(empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$name=$_POST['e_name'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_spec`='$spec'";
												}
									
												//Email and specialist
												if(!empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$email=$_POST['e_email'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_email`='$email' AND `e_spec`='$spec'";
												}
									
												//Name , email and Specialist
												else if(!empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$name=$_POST['e_name'];
													$email=$_POST['e_email'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_email`='$email' AND `e_spec`='$spec'";
												}
									
												//Name , from and to
												else if(!empty($_POST['e_name']) && !empty($_POST['date_from']) && !empty($_POST['date_to']) && empty($_POST['e_email']) && empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$to=$_POST['date_to'];
													$name=$_POST['e_name'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_date` BETWEEN '$from' AND '$to'";
												}
									
												//Email , from and to
												else if(!empty($_POST['e_email']) && !empty($_POST['date_from']) && !empty($_POST['date_to']) && empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$to=$_POST['date_to'];
													$email=$_POST['e_email'];
													$query="SELECT * FROM `employee` WHERE `e_email`='$email' AND `e_date` BETWEEN '$from' AND '$to'";
												}
									
												//Specialist , from and to
												else if(!empty($_POST['e_spec']) && !empty($_POST['date_from']) && !empty($_POST['date_to']) && empty($_POST['e_email']) && empty($_POST['e_name'])){
													$from=$_POST['date_from'];
													$to=$_POST['date_to'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_spec`='$spec' AND `e_date` BETWEEN '$from' AND '$to'";
												}
									
												//Name , email , from and to
												else if(!empty($_POST['e_email']) && !empty($_POST['date_from']) && !empty($_POST['date_to']) && !empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$to=$_POST['date_to'];
													$name=$_POST['e_name'];
													$email=$_POST['e_email'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_email`='$email' AND `e_date` BETWEEN '$from' AND '$to'";
												}
									
												//Name , specialist , from and to
												else if(empty($_POST['e_email']) && !empty($_POST['date_from']) && !empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$to=$_POST['date_to'];
													$name=$_POST['e_name'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_spec`='$spec' AND `e_date` BETWEEN '$from' AND '$to'";
												}
									
												//Mail , specialist , from and to
												else if(!empty($_POST['e_email']) && !empty($_POST['date_from']) && !empty($_POST['date_to']) && empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$to=$_POST['date_to'];
													$email=$_POST['e_email'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_email`='$email' AND `e_spec`='$spec' AND `e_date` BETWEEN '$from' AND '$to'";
												}			
									
												//From and to
												else if(!empty($_POST['date_from']) && !empty($_POST['date_to']) && empty($_POST['e_name']) && empty($_POST['e_email']) && empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$to=$_POST['date_to'];
													$query="SELECT * FROM `employee` WHERE `e_date` BETWEEN '$from' AND '$to'";
												}
									
												//Name and from
												else if(empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['date_from']) && empty($_POST['e_email']) && empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$name=$_POST['e_name'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_date` >= '$from'";
												}
									
												//Email and from
												else if(empty($_POST['date_to']) && !empty($_POST['e_email']) && !empty($_POST['date_from']) && empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$email=$_POST['e_email'];
													$query="SELECT * FROM `employee` WHERE `e_email`='$email' AND `e_date` >= '$from'";
												}
									
												//Specialist and from
												else if(empty($_POST['date_to']) && !empty($_POST['e_spec']) && !empty($_POST['date_from']) && empty($_POST['e_email']) && empty($_POST['e_name'])){
													$from=$_POST['date_from'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_spec`='$spec' AND `e_date` >= '$from'";
												}
									
												//Name , mail and from
												else if(!empty($_POST['e_email']) && !empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$name=$_POST['e_name'];
													$email=$_POST['e_email'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_email`='$email' AND `e_date` >= '$from'";
												}
									
												//Name , specialist and from
												else if(empty($_POST['e_email']) && !empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$name=$_POST['e_name'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_spec`='$spec' AND `e_date` >= '$from'";
												}
									
												//Mail , specialist and from
												else if(!empty($_POST['e_email']) && !empty($_POST['date_from']) && empty($_POST['date_to']) && empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$email=$_POST['e_email'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_email`='$email' AND `e_spec`='$spec' AND `e_date` >= '$from'";
												}			
									
												//Name , mail , specialist and from
												else if(!empty($_POST['e_email']) && !empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$from=$_POST['date_from'];
													$name=$_POST['e_name'];
													$email=$_POST['e_email'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_email`='$email' AND `e_spec`='$spec' AND `e_date` >= '$from'";
												}
									
												//from
												else if(empty($_POST['date_to']) && !empty($_POST['date_from']) && empty($_POST['e_name']) && empty($_POST['e_spec']) && empty($_POST['e_email'])){
													$from=$_POST['date_from'];
													$query="SELECT * FROM `employee` WHERE `e_date` >= '$from'";
												}
									
												//Name and to
												else if(!empty($_POST['date_to']) && !empty($_POST['e_name']) && empty($_POST['date_from']) && empty($_POST['e_email']) && empty($_POST['e_spec'])){
													$to=$_POST['date_to'];
													$name=$_POST['e_name'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_date` <= '$to'";
												}
									
												//Email and to
												else if(!empty($_POST['date_to']) && !empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$to=$_POST['date_to'];
													$email=$_POST['e_email'];
													$query="SELECT * FROM `employee` WHERE `e_email`='$email' AND `e_date` <= '$to'";
												}
									
												//Specialist and to
												else if(!empty($_POST['date_to']) && !empty($_POST['e_spec']) && empty($_POST['date_from']) && empty($_POST['e_email']) && empty($_POST['e_name'])){
													$to=$_POST['date_to'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_spec`='$spec' AND `e_date` <= '$to'";
												}
									
												//Name , email and to
												else if(!empty($_POST['e_email']) && empty($_POST['date_from']) && !empty($_POST['date_to']) && !empty($_POST['e_name']) && empty($_POST['e_spec'])){
													$to=$_POST['date_to'];
													$name=$_POST['e_name'];
													$email=$_POST['e_email'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_email`='$email' AND `e_date` <= '$to'";
												}
									
												//Name , specialist and to
												else if(empty($_POST['e_email']) && empty($_POST['date_from']) && !empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$to=$_POST['date_to'];
													$name=$_POST['e_name'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_spec`='$spec' AND `e_date` <= '$to'";
												}
									
												//Email , specialist and to
												else if(!empty($_POST['e_email']) && empty($_POST['date_from']) && !empty($_POST['date_to']) && empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$to=$_POST['date_to'];
													$email=$_POST['e_email'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_email`='$email' AND `e_spec`='$spec' AND `e_date` <= '$to'";
												}
									
												//Name , email , specialist and to
												else if(!empty($_POST['e_email']) && empty($_POST['date_from']) && !empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
													$to=$_POST['date_to'];
													$name=$_POST['e_name'];
													$email=$_POST['e_email'];
													$spec=$_POST['e_spec'];
													$query="SELECT * FROM `employee` WHERE `e_name`='$name' AND `e_email`='$email' AND `e_spec`='$spec' AND `e_date` <= '$to'";
												}
									
												//to
												else if(!empty($_POST['date_to']) && empty($_POST['date_from']) && empty($_POST['e_name']) && empty($_POST['e_email']) && empty($_POST['e_spec'])){
													$to=$_POST['date_to'];
													$query="SELECT * FROM `employee` WHERE `e_date` <= '$to'";
												}
												$res = mysqli_query($dbcon,$query);
												$count = 0;
												$num=mysqli_num_rows($res);
												if($num==0){
													echo "<h2 class='text-danger' style='text-align:center;'>No records found!</h2>";
												}
										else{?>
								<h2 class="text-primary align-center">EMPLOYEE REPORT</h2>
							<?php if(!empty($_POST['date_from']) && !empty($_POST['date_to'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>FROM : <?php echo $from;?></h4>
								<h4 class='col-md-6 align-right m-t-30 m-b-30'>TO : <?php echo $to;?></h4>
							<?php } ?>
							<?php if(!empty($_POST['date_from']) && empty($_POST['date_to'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>FROM : <?php echo $from;?></h4>
							<?php }?>
							<?php if(empty($_POST['date_from']) && !empty($_POST['date_to'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>UPTO : <?php echo $to;?></h4>
							<?php }?>
							<?php if(empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && empty($_POST['e_spec'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>NAME : <?php echo $name;?></h4>
							<?php }?>
							<?php if(!empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && empty($_POST['e_name']) && empty($_POST['e_spec'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>EMAIL : <?php echo $email;?></h4>
							<?php }?>
							<?php if(empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && empty($_POST['e_name']) && !empty($_POST['e_spec'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>SPECIALIST IN : <?php echo $spec;?></h4>
							<?php }?>
							<?php if(!empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && empty($_POST['e_spec'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>NAME : <?php echo $name;?></h4>
								<h4 class='col-md-6 align-right m-t-30 m-b-30'>EMAIL : <?php echo $email;?></h4>
							<?php } ?>
							<?php if(empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>NAME : <?php echo $name;?></h4>
								<h4 class='col-md-6 align-right m-t-30 m-b-30'>SPECIALIST IN : <?php echo $spec;?></h4>
							<?php } ?>
							<?php if(!empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && empty($_POST['e_name']) && !empty($_POST['e_spec'])){
							?>
								 <h4 class='col-md-6 align-left m-t-30 m-b-30'>EMAIL : <?php echo $email;?></h4>
								<h4 class='col-md-6 align-right m-t-30 m-b-30'>SPECIALIST IN : <?php echo $spec;?></h4>
							<?php } ?>
							<?php if(!empty($_POST['e_email']) && empty($_POST['date_from']) && empty($_POST['date_to']) && !empty($_POST['e_name']) && !empty($_POST['e_spec'])){
							?>
								 <h4 class='col-md-4 align-left m-t-30 m-b-30'>NAME : <?php echo $name;?></h4>
								<h4 class='col-md-4 align-center m-t-30 m-b-30'>EMAIL : <?php echo $email;?></h4>
								<h4 class='col-md-4 align-right m-t-30 m-b-30'>SPECIALIST IN : <?php echo $spec;?></h4>
							<?php } ?>
								<table id="datatable" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Employee Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Alternative Mobile</th>
                                        <th>Specialist In</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
								<?php
								while($rows=mysqli_fetch_assoc($res)){
									$count++;
								?>
                              	<tbody><tr>
                                        <td scope="row"><?php echo $count?></td>
                                        <td id="ename"><?php echo $rows["e_name"]?></td>
                                        <td id="eemail"><?php echo $rows["e_email"]?></td>
                                        <td id="emobno"><?php echo $rows["e_mobno"]?></td>
                                        <td id="ealtermob"><?php echo $rows["e_altermob"]?></td>
                                        <td id="espec"><?php echo $rows["e_spec"]?></td>
										<?php if(!strcmp($rows['e_status'],'Enable')){?>
										<td id="sts"><span class="label bg-green"><?php echo $rows['e_status'];?></span></td>
										<?php } ?>
										<?php if(!strcmp($rows['e_status'],'Disable')){ ?>
										<td id="sts"><span class="label bg-grey"><?php echo $rows['e_status'];?></span></td>
										<?php } ?>
                                    </tr>
									 <?php } ?>
								</tbody></table>
								<?php
								} 
								}
									
						?>
                        </div>
					</div>
                    </div>
                </div>
				<div class="col-md-12 align-right">
					<button  class="btn btn-danger waves-effect m-r-10 " onclick="generatePDF()">EXPORT AS PDF</button>
					<!--<button  class="btn btn-danger waves-effect" id="CSVbutton">EXPORT AS CSV</button>-->
				</div>

            </div><br><br>

            <!-- #END# Striped Rows -->
        </div>
    </section>
	<!-- Default Size -->
            </div>
	<!--<script>
			let csv=[];
			let tr=document.querySelectorAll("tr");
			for(let i=0;i<tr.length;i++){
				//console.log(tr[i]);
				let cols=tr[i].querySelectorAll("th,td");
				let csvRow=[];
				for(j=0;j<cols.length;j++){
					csvRow.push(cols[j].innerHTML)
				}
				csv.push(csvRow.join(","))
			}
			console.log(csv.join("\n"));
			let blob=new Blob([csv.join("\n")],{type:"text/csv"});
			let ce = document.createElement("a");
			ce.innerHTML="Download";
			ce.download="EmployeeReport"
			ce.href=URL.createObjectURL(blob);
			document.body.appendChild(ce);
		</script>-->
    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>
	
	<!-- Autosize Plugin Js -->
    <script src="plugins/autosize/autosize.js"></script>
	
	<!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>
	
	<!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
	
	 <!-- Bootstrap Datepicker Plugin Js -->
    <script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
	<script src="js/basic-form-elements.js"></script>

    <!-- Demo Js -->
</body>

</html>
