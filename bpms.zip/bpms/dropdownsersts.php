
<?php

    $sts = $_POST["csts"];
    if($sts == 'Waiting'){
        echo '<label for="ssts">Service Status</label>';
		echo "<br>";
        echo '<select class="form-control" name="ssts" required>';
		echo '<option value="Waiting" selected>Waiting</option>
			 <option value="Inprogress">Inprogress</option>
             <option value="Completed">Completed</option>';
        echo '</select>';
    } 
	else if($sts == 'Inprogress'){
		echo '<label for="ssts">Service Status</label>';
		echo "<br>";
        echo '<select class="form-control" name="ssts" required>';
		echo '<option value="Waiting">Waiting</option>
			 <option value="Inprogress" selected>Inprogress</option>
             <option value="Completed">Completed</option>';
        echo '</select>';
	}
	else{
		echo '<label for="ssts">Service Status</label>';
		echo "<br>";
        echo '<select class="form-control" name="ssts" required>';
		echo '<option value="Waiting">Waiting</option>
			 <option value="Inprogress">Inprogress</option>
             <option value="Completed" selected>Completed</option>';
        echo '</select>';
	}

?>