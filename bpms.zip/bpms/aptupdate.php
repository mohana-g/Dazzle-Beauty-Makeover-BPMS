<?php
	$p = $_POST["submit"];
	$name = $_POST["cname"];
	$cser = $_POST["cser"];
	$cemp = $_POST["cemp"];
	$capdate = $_POST["capdate"];
	$captime = $_POST["captime"];
	$camt = $_POST["camt"];
	$psts = $_POST["psts"];
	$ssts = $_POST["ssts"];

	include('connection.php');
	$query = "UPDATE appointment SET cus_ser= '$cser' , ref_emp= '$cemp' , apt_date='$capdate' , apt_time='$captime' ,
	amt='$camt' , pay_sts='$psts' , ser_sts='$ssts' WHERE cus_name='$name'";
	$res =mysqli_query($con,$query);
	if($res){
		header('location:appointments.php?page='.$p.'');
	}
	else{
		echo "Error";
	}
?>