
<html>
<body>
<?php
	session_start();
	$name = $_POST["a_name"];
	$password1 = $_POST["a_pass"];
	$_SESSION["username"] = $name;
	
	include('connection.php');
	$query = "SELECT * FROM admin WHERE a_name = '$name'";
	$res = mysqli_query($con,$query);
	$row = mysqli_fetch_assoc($res);
	$password = $row["a_pass"];
	if($password1 == $password){
		header('location:toast.php');
	}
	else{
		echo "<script>
                  alert('Incorrect password');
                  window.location = 'login.html';
            </script>";
	}
?>
	</body>
</html>