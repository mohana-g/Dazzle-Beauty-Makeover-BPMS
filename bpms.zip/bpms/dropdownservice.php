<?php
	
	include('connection.php');
	$service = $_POST["cser"];
	$squery = "SELECT * FROM service";
	$res = mysqli_query($con,$squery);
	echo "<label for='cservice'>Service</label>";
	echo "<br>";
    echo '<select class="form-control cservice" name="cservice">';
	while($row = mysqli_fetch_assoc($res)){
		if($row["ser_sts"]=="Enable"){
			$ser = $row["ser_name"];
			if($ser == $service){
				echo '<option value="'.$ser.'" selected>'.$ser.'</option>';
			}
			else{
				echo '<option value="'.$ser.'">'.$ser.'</option>';
			}
		}
	}
	echo '</select>';

?>