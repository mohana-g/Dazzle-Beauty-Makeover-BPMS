<?php 

	session_start(); 
	include('connection.php');

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Welcome To | Dazzle Beauty Makeover </title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="boot/css/bootstrap.css">
	<script src="boot/js/bootstrap.bundle.min.js" type="text/javascript"></script>
	
</head>
<body>
	
	<?php 
	
		$uname = $_SESSION["username"]; 
		$ad_query = "SELECT * FROM admin WHERE a_name='$uname'";
		$ad_res = mysqli_query($con,$ad_query);
		$res_row = mysqli_fetch_assoc($ad_res);
		$time = $res_row["logout_time"];
		$ad_query = " SELECT * FROM appointment WHERE date BETWEEN '$time' AND  CURRENT_TIMESTAMP ";
		$ad_res = mysqli_query($con,$ad_query);
		$ad_count = mysqli_num_rows($ad_res);
		
	?>
	<div class="container">
		<div class="row m-2">
			<div class="col-lg-4"></div>
			<div class="col-lg-4">
				<div class="toast-header">
					<h4 class="me-auto p-3">New Appointments</h4>
					<button type="button" class="btn-close" onclick="location.href='home.php';" data-bs-dismiss="toast" aria-label="Close"></button>
				</div>
				<div class="toast-body px-4">
					<h5>You have received <?php echo $ad_count; ?> new appointments</h5>
				</div>
			</div>
			<div class="col-lg-4"></div>
		</div>
	</div>
	
</body>
</html>