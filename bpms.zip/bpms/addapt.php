<?php

	$p = $_POST["submit"];
	$cname=$_POST['cname'];
	$cmail=$_POST['cmail'];
	$capdate=$_POST['capdate'];
	$captime=$_POST['captime'];
	$cemp=$_POST['cemp'];
	$cser=$_POST['cser'];
	$camt=$_POST['camt'];

	include('connection.php');
	$query = "INSERT INTO appointment(cus_name, cus_mail, cus_ser, ref_emp, apt_date, apt_time, amt) VALUES ('$cname','$cmail','$cser','$cemp','$capdate','$captime','$camt')";
	$res = mysqli_query($con,$query);

	$query = "SELECT * FROM cus WHERE cus_name = '$cname'";
	$res = mysqli_query($con,$query); 
	$count = mysqli_num_rows($res);

	if($count==0){
		$query = "INSERT INTO cus(cus_name, cus_mail) VALUES('$cname','$cmail')";
		$res = mysqli_query($con,$query);
		echo "<script>alert('New Customer is inserted')</script>";
	}

	if($res){
		header('location:appointments.php?page='.$p.'');
	}
 	else{
		echo "error";
	}

?>