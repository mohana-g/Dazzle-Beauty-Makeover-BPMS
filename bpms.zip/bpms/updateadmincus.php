<?php 
	session_start();
	$upass = $_POST["submit"];
	
	include('connection.php');
	$aname = $_POST["a_name"];
	$amail = $_POST["a_mail"];
	$amob = $_POST["a_mob"];
	$aadd = $_POST["a_add"];
	$apass = $_POST["a_pass"];
	
	if($upass == $apass){
		$query = "UPDATE admin SET a_name='$aname',a_mob='$amob',a_mail='$amail',a_add='$aadd' WHERE a_pass='$apass'";
		$res = mysqli_query($con,$query);
		header('location:customer.php');
	}
	else{
		echo "<script>
                  alert('Updation Failed-Incorrect password!!');
                  window.location = 'customer.php';
            </script>";
	}
?>
