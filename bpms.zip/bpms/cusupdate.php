<?php

	$p = $_POST["submit"];
	$name = $_POST["cname"];
	$mail = $_POST["cmail"];
	$mob = $_POST["cmob"];
	$amob = $_POST["camob"];
	$gen = $_POST["cgen"];
	include('connection.php');
	$query = "UPDATE cus SET cus_name='$name' , cus_mail= '$mail' , cus_mob= '$mob' , cus_amob='$amob' , cus_gen='$gen' WHERE cus_mail='$mail'";
	$res =mysqli_query($con,$query);
	if($res){
		header('location:customer.php?page='.$p.'');
	}
	else{
		echo "Error";
	}

?>