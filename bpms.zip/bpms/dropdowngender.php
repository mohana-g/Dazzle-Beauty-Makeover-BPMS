
<?php
    $gen = $_POST["cgen"];
    if($gen == 'Female'){
        echo "<label for='name'>Gender</label>";
		echo "<br>";
        echo "<select class='form-control' name='cgen' required>";
		echo "<option value='Male'>Male</option>
			 <option value='Female' selected>Female</option>";
        echo "</select>";
    } 
	else{
		 echo "<label for='name'>Gender</label>";
		echo "<br>";
        echo "<select class='form-control' name='cgen' required>";
		echo "<option value='Male' selected>Male</option>
			 <option value='Female'>Female</option>";
        echo "</select>";
	}
?>