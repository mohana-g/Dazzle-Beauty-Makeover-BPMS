<?php

	$cname = $_POST['cname'];
	$cmail = $_POST['cmail'];
	$cmob = $_POST['cmob'];
	$camob = $_POST['camob'];
	$capdate = $_POST['capdate'];
	$captime = $_POST['captime'];
	$cgen = $_POST['cgen'];
	$cemp = $_POST['cemp'];
	$cser = $_POST['cser'];
	$camt = $_POST['camt'];

	include('connection.php');

	$query = "SELECT * FROM cus WHERE cus_name='$cname' AND cus_mail='$cmail';";
	$res = mysqli_query($con,$query);
	$count = mysqli_num_rows($res);
	echo $count;

	if($count!=1){
		$query1 = "INSERT INTO cus(cus_name, cus_mail, cus_mob, cus_amob, cus_gen) VALUES ('$cname','$cmail','$cmob','$camob','$cgen')";
		$res1 = mysqli_query($con,$query1);
	}

	$query2 = "INSERT INTO appointment(cus_name, cus_mail, cus_ser, ref_emp, apt_date, apt_time, amt) VALUES ('$cname','$cmail','$cser','$cemp','$capdate','$captime','$camt')";

	if(mysqli_query($con,$query2)){
		header('location:mainpage.php');
	}
 	else{
		echo "error";
	}

?>