<?php 
	include('connection.php');
	$mail = $_POST['cmail'];
	$query = "DELETE FROM cus WHERE cus_mail ='$mail' ";
	$res = mysqli_query($con,$query);
?>