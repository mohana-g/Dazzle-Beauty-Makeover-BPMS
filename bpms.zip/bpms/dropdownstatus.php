
<?php
    $sts = $_POST["csts"];
    if($sts == 'Enable'){
		echo "<label>Status</label>";
		echo "<br>";
		echo "<select class='form-control' name='ests'>";
		echo "<option value='Enable' selected>Enable</option>";
		echo "<option value='Disable'>Disable</option>";
		echo "</select>";
    } 
	else{
		echo "<label>Status</label>";
		echo "<br>";
		echo "<select class='form-control' name='ests'>";
		echo "<option value='Enable'>Enable</option>";
		echo "<option value='Disable' selected>Disable</option>";
		echo "</select>";
	}
?>