<?php 
	include('connection.php');
	$name = $_POST['sname'];
	$query = "DELETE FROM service WHERE ser_name ='$name' ";
	$res = mysqli_query($con,$query);
	if($res){
		echo 1;
	}
	else{
		echo 0;
	}
?>