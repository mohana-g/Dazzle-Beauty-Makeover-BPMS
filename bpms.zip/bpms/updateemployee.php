<?php
	$p = $_POST["submit"];
	$name = $_POST["ename"];
	$email = $_POST["eemail"];
	$mobno = $_POST["emobno"];
	$altermob = $_POST["ealtermob"];
	$spec = $_POST["espec"];
	$sts = $_POST["ests"];
	include('connection.php');
	$query = "UPDATE employee SET e_name='$name',e_email='$email',e_mobno='$mobno',e_altermob='$altermob',e_spec='$spec',e_status='$sts' WHERE e_name='$name'";
	$res =mysqli_query($con,$query);
	if($res){
		header('location:employee.php?page='.$p.'');
	}
	else{
		echo "Error";
	}
?>