<?php

	$p = $_POST["submit"];
	$sname=$_POST['sname'];
	$sdur=$_POST['sdur'];
	$scost=$_POST['scost'];
	$ssts=$_POST['ssts'];
	$scolor=$_POST['scolor'];
	$sdate=$_POST['sdate'];
	include('connection.php');
	$query = "INSERT INTO service VALUES('$sname','$scost','$sdur','$ssts','$scolor','$sdate')";
	$res = mysqli_query($con,$query);
	if($res){
		header('location:services.php?page='.$p.'');
	}
 	else{
		echo "error";
	}

?>