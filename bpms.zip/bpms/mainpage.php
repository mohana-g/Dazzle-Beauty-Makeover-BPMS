<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome To | Dazzle Beauty Makeover </title>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" language="javascript" src="fontawesome/js/all.js"  crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script type="text/javascript" src="js/bootstrap.bundle.js"></script>
	<link rel="stylesheet" type="text/css" href="Main.css">
	<link href="plugins/node-waves/waves.css" rel="stylesheet" />

	<script src="jquery.js" type="text/javascript"></script>
    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />
	
	<!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>
	
	<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
	
	<!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />
	
	<!-- Bootstrap DatePicker Css -->
    <link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" />
	
	<!-- Bootstrap Select Css -->
    <link href="plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
</head>
<body>
	<div class="background">
		<div class="container-fluid">
			<nav class="navbar navbar-expand-sm bg-transparent navbar-dark float-end text-black">
	<div class="container-fluid">
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapisbleNavbar">
		<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="collapisbleNavbar">
		<ul class="navbar-nav mt-3 p-5 gap-3">
		<li class="nav-item"><a href="#" class="nav-link text-danger"><b>Home</b></a></li>
		<li class="nav-item"><a href="#" class="nav-link text-dark">About</a></li>	
		<li class="nav-item dropdown">
			<a class="nav-link text-dark dropdown-toggle" href="#" rel="button" data-bs-toggle="dropdown">Services</a>
			<ul class="dropdown-menu bg-transparent dropdown-menu-dark">
				<li><a href="#" class="dropdown-item text-dark">Facial</a></li>
				<li><a href="#" class="dropdown-item text-dark">Bridal Makeup</a></li>
				<li><a href="#" class="dropdown-item text-dark">Tattoo designing</a></li>
				<li><a href="#" class="dropdown-item text-dark">Face Whitening treatment</a></li>
			</ul>
		</li>
		<li class="nav-item textclr"><a href="#" class="nav-link text-dark">Contact</a></li>
		<li class="nav-item"><a href="login.html"><button type="button" class="btn btn-outline-dark">Log In</button></a></li>
		<li class="nav-item"><button type="button" class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#addnew-modal">Book Appointment</button></li>
		</ul>
		</div>
	</div>
	</nav>
		 <div class="modal fade" id="addnew-modal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
						<form action="addmainpagecus.php" method="post">
                        <div class="modal-header bg-danger text-white">
                            <h4 class="modal-title" id="addnew-modalLabel">Book Appointment</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix mt-4">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cname">Name</label>
                                            <input type="text" class="form-control" name="cname"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmail">Email</label>
                                            <input type="text" class="form-control" name="cmail"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix mt-4">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmob">Mobile #</label>
                                            <input type="text" class="form-control" name="cmob"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="camob">Alternative Mobile #</label>
                                            <input type="text" class="form-control" name="camob"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix mt-4">
								<div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="capdate">App.Date</label>
                                            <input type="date" class="datepicker form-control" name="capdate">
                                        </div>
                                    </div>
                                </div>
								<div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="captime">App.Time</label>
                                            <input type="time" class="timepicker form-control" name="captime">
                                        </div>
                                    </div>
                                </div>
							</div>
							<div class="row clearfix mt-4">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cgen">Gender</label>
                                            <select class="form-control" name="cgen">
												<option value="">-- Please select --</option>
												<option value="Male">Male</option>
												<option value="Female">Female</option>
                                    </select>
                                        </div>
                                    </div>
                                </div>
								<div class="col-sm-6">
									<label for="cemp">Employee</label>
                                        <select class="form-control cemp" name="cemp">
											<option value="">-- Please select --</option>
											<?php
												$squery = "SELECT * FROM employee";
												include('connection.php');
												$res = mysqli_query($con,$squery);
												while($row = mysqli_fetch_assoc($res)){
													if($row["e_status"]=="Enable"){
														$ser = $row["e_name"];
														echo '<option value="'.$ser.'">'.$ser.'</option>';
													}
												}
											?>
                                    	</select>
                                </div>
                            </div>
							<div class="row clearfix mt-4">
								<div class="col-sm-6">
										<div class="form-group">
                                        <div class="form-line"><label for="cser">Service</label>
                                        <select class="form-control cser" name="cser">
											<option value="">-- Please select --</option>
											<?php
												$squery = "SELECT * FROM service";
												include('connection.php');
												$res = mysqli_query($con,$squery);
												while($row = mysqli_fetch_assoc($res)){
													if($row["ser_sts"]=="Enable"){
														$ser = $row["ser_name"];
														echo '<option value="'.$ser.'">'.$ser.'</option>';
													}
												}
											?>
                                    	</select>
										</div>
                                    </div>
                                </div>
								<div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="camt">Amount</label>
											<div class="form-line"><input type="text" name="camt" id="amtres" class="form-control"/></div>
                                        </div>
                                    </div>
                                </div>
							</div>
						</div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" >SAVE</button>
                            <button type="button" class="btn btn-danger waves-effect" data-bs-dismiss="modal">CANCEL</button>
                        </div>
						</form>
						 </div>
                    </div>
                </div>
            </div>
	</div>
	<section class="container mt-5">
		<h6 class="text-center text-danger">PRICING</h6>
		<h4 class="text-center">Our Services Prices</h4>
		<p class="text-center">Get a wow experience with us,customer happiness makes us better..</p>
		 <div class="body table-responsive p-5">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="text-danger">
                                        <th>#</th>
                                        <th>Service Name</th>
                                        <th>Service Price</th>
                                    </tr>
                                </thead>
                                <tbody>
									<?php
											include('connection.php');
											$select = "SELECT * FROM service";
											$res = mysqli_query($con,$select);
											$var=0;
											while($r = mysqli_fetch_assoc($res)){
												if($r["ser_sts"]=="Enable"){
													$var++;
													$dis= '<tr><td>'.$var.'</td>
															<td id="name">'.$r["ser_name"].'</td>
															<td id="amt">'.$r["ser_amt"].'</td></tr>';
													echo $dis;
												}
											}
											
										?>
                                    </tbody>
			 						</table>
                        </div>
	</section>
	<section class="container-fluid bg-dark">
		<div class="row">
			<div class="col-lg-4">
				<div class="p-5 text-white-50">
				<h4>About..</h4><br>
				<p>Our main focus is on  quality and hygiene,for better experience for our customer.Our Parlour is well equipped with advanced technology equipments and provides best quality services.Our staff is well trained and experienced....Offering more</p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="p-5 text-white-50">
				<h4>Specified Services..</h4><br>
				<p>Bridal Makeup</p>
				<p>Nail Art</p>
				<p>Tattoo Designing</p>
				<p>Facial</p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="p-5 text-white-50">
				<h4>Have a Question?</h4><br>
				<p><span class="fa fa-location-dot"></span> 34,sector 19,Gyan Sarovar street,Gail Noida (Mumbai/NCR)</p>
				<p><span class="fa fa-phone"></span> +919765432121</p>
				<p><span class="fa fa-message"></span> info@gamil.com</p>
				</div>
			</div>
		</div>
	</section>
</body><script>
		$(document).ready(function(){
			$("select.cser").change(function(){
				var selectedService = $(".cser option:selected").val();
				$.ajax({
					type: "POST",
					url: '/bpms/Ajax.php',
					data: { service : selectedService },
					success: function(data){
						$("#amtres").val(data);
					}
				});
			});
		});
</script>
</html>
