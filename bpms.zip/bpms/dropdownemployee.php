<?php
	
	include('connection.php');
	$service = $_POST["cemp"];
	$squery = "SELECT * FROM employee";
	$res = mysqli_query($con,$squery);
	echo '<label for="cemp">Employee</label>';
	echo "<br>";
    echo ' <select class="form-control cemp" name="cemp">';
	while($row = mysqli_fetch_assoc($res)){
		if($row["e_status"]=="Enable"){
			$ser = $row["e_name"];
			if($ser == $service){
				echo '<option value="'.$ser.'" selected>'.$ser.'</option>';
			}
			else{
				echo '<option value="'.$ser.'">'.$ser.'</option>';
			}
		}
	}

?>