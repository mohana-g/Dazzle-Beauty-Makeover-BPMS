<?php

	$p = $_POST["submit"];
	$cname=$_POST['cname'];
	$cmail=$_POST['cmail'];
	$cmob=$_POST['cmob'];
	$camob=$_POST['camob'];
	$cgen=$_POST['cgen'];
	
	include('connection.php');
	$query = "INSERT INTO cus(cus_name, cus_mail, cus_mob, cus_amob, cus_gen) VALUES ('$cname','$cmail','$cmob','$camob','$cgen')";

	$res = mysqli_query($con,$query);
	if($res){
		header('location:customer.php?page='.$p.'');
	}
 	else{
		echo "error";
	}

?>