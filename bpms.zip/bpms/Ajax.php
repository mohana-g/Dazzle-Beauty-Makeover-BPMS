<?php

	$ser=$_POST["service"];
	include_once("connection.php");
	$sel="SELECT * FROM service WHERE ser_name='$ser'";
	$res=mysqli_query($con,$sel);
	$rows=mysqli_fetch_assoc($res);
	$amt=$rows['ser_amt'];
	echo $amt;

?>