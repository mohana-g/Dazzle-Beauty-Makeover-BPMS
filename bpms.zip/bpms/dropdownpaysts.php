
<?php

    $sts = $_POST["csts"];
    if($sts == 'Paid'){
        echo '<label for="psts">Payment Status</label>';
		echo "<br>";
        echo '<select class="form-control show-tick" name="psts" required>';
		echo '<option value="Paid">Paid</option>
			 <option value="Unpaid" selected>Unpaid</option>';
        echo '</select>';
    } 
	else{
		  echo '<label for="psts">Payment Status</label>';
		echo "<br>";
        echo '<select class="form-control show-tick" name="psts" required>';
		echo '<option value="Paid" selected>Paid</option>
			 <option value="Unpaid">Unpaid</option>';
        echo '</select>';
	}

?>