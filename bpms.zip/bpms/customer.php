<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Welcome To | Dazzle Beauty Makeover </title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">

	<link href="fontAwesome/css/all.css" rel="stylesheet" type="text/css">
	<script src="fontAwesome/js/all.js" type="text/javascript"></script>
	<script src="jquery.js" type="text/javascript"></script>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />
	
	<!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>
	
	<!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />
	
	<!-- Bootstrap DatePicker Css -->
    <link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" />
	
	<!-- Bootstrap Select Css -->
    <link href="plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
</head>

<body class="theme-purple">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="index.html">Dazzle Beauty Makeover - Parlour Management</a>
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="info-container">
                    <?php 
						$uname = $_SESSION["username"]; 
						include('connection.php');
						$aquery = "SELECT * FROM admin WHERE a_name='$uname'";
						$res = mysqli_query($con,$aquery);
						$ares = mysqli_fetch_assoc($res);
					?>
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $ares["a_name"];?></div>
                    <div class="email"><?php echo $ares["a_mail"];?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a data-toggle="modal" data-target="#addnew-modalp"><i class="material-icons">person</i>Profile</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="login.html" id="logout"><i class="material-icons">input</i>Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>
                    <li><a href="home.php"><i class="material-icons">home</i><span>Home</span></a></li>
                    <li><a href="appointments.php"><i class="material-icons">event</i><span>Appointments</span></a></li>
                    <li><a href="services.php"><i class="material-icons">menu</i><span>Services</span></a></li>
                    <li><a href="employee.php"><i class="material-icons">face</i><span>Employee</span></a></li>
					<li class="active"><a href="customer.php"><i class="material-icons">people</i><span>Customer</span></a></li>
					<li><a href="#" class="menu-toggle"><i class="material-icons">report</i><span>Reports</span></a>
						<ul class="ml-menu">
						<li><a href="AppointmentsReport.php">Appointments</a></li>
						<li><a href="ServiceReport.php">Services</a></li>	
						<li><a href="EmployeeReport.php">Employees</a></li>	
						<li><a href="CustomerReport.php">Customer</a></li>		
						</ul>
					</li>
                </ul>
            </div>
            <!-- #Menu -->
            
        </aside>
        <!-- #END# Left Sidebar -->
    </section>
	
	<div class="modal fade" id="addnew-modalp" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="addnew-modalLabel">Profile</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cname">Name</label>
                                            <input type="text" class="form-control" name="cname" value="<?php echo $ares["a_name"]; ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmail">Email</label>
                                            <input type="text" class="form-control" name="cmail" value="<?php echo $ares["a_mail"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmob">Mobile</label>
                                            <input type="text" class="form-control" name="cmob" value="<?php echo $ares["a_mob"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="camob">Address</label>
                                            <input type="text" class="form-control" name="camob" value="<?php echo $ares["a_add"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" name="submit" value="<?php echo $page?>" data-toggle="modal" data-target="#addnew-modalp1">EDIT</button>
                            <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">CANCEL</button>
                        </div>
                    </div>
                </div>
            </div>
	
			<div class="modal fade" id="addnew-modalp1" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
						<form action="updateadmincus.php" method="post">
                        <div class="modal-header">
                            <h4 class="modal-title" id="addnew-modalLabel">Edit Profile</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_name">Name</label>
                                            <input type="text" class="form-control" name="a_name" value="<?php echo $ares["a_name"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_mail">Email</label>
                                            <input type="text" class="form-control" name="a_mail" value="<?php echo $ares["a_mail"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_mob">Mobile</label>
                                            <input type="text" class="form-control" name="a_mob" value="<?php echo $ares["a_mob"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_add">Address</label>
                                            <input type="text" class="form-control" name="a_add" value="<?php echo $ares["a_add"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_pass">Password</label>
                                            <input type="password" class="form-control" name="a_pass" required/>
                                        </div>
                                    </div>
								</div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" value="<?php echo $ares["a_pass"]; ?>" name="submit">UPDATE</button>
                            <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">CANCEL</button>
                        </div>
						</form>
                    </div>
                </div>
            </div>
	
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>CUSTOMERS</h2>
            </div>            
            <!-- Striped Rows -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>CUSTOMERS</h2>
                        </div>
                        <div class="body table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Customer Name</th>
                                        <th>Email</th>
                                        <th>Mobile #</th>
                                        <th>Alternative Mobile #</th>
                                        <th>Gender</th>
                                        <th>Profile</th>
                                        <th>Action</th>
										
                                    </tr>
                                </thead>
                                <tbody>
									<?php
										$host = "localhost";
										$dbuser = "root";
										$pass = "";
										$db = "bpms";
										$con = mysqli_connect($host,$dbuser,$pass,$db);
										$query = "SELECT * from cus";
										$num = 7;
										$res = mysqli_query($con,$query);
										$t = mysqli_num_rows($res);
										$total_page = ceil($t/$num);
										if(isset($_GET["page"])){
											$page = $_GET["page"];
										}
										else{
											$page = 1;
										}
										if($page==$total_page){
											$next = $total_page;
										}
										else{
											$next = $page+1;
										}
										if($page==1){
											$prev = 1;
										}
										else{
											$prev = $page-1;
										}
										$start = ($page-1)*$num;
										$query = "SELECT * FROM cus ORDER BY cus_date DESC limit $start,$num";
										$res = mysqli_query($con,$query);
										$var = (($page-1)*$num);
										while($r = mysqli_fetch_assoc($res)){
											$var++;
											$dis='<tr><th scope="row">'.$var.'</th>
													<td id="name">'.$r["cus_name"].'</td>
													<td id="mail">'.$r["cus_mail"].'</td>
													<td id"mob">'.$r["cus_mob"].'</td>
													<td id="amob">'.$r["cus_amob"].'</td>
													<td id="gen">'.$r["cus_gen"].'</td>';
													echo $dis;
													?>
													<td><img src="images/user2.png" width="25" height="25" alt=""/></td>
													<td><button type="button" class="btn btn-xs btn-primary waves-effect update" data-toggle="modal" data-id='<?php echo $r["cus_name"]; ?>' data-mail='<?php echo $r["cus_mail"]; ?>' data-mob='<?php echo $r["cus_mob"]; ?>' data-amob='<?php echo $r["cus_amob"]; ?>' data-gen='<?php echo $r["cus_gen"]; ?>' data-target="#defaultModal"><i class="material-icons">mode_edit</i></button>&nbsp;&nbsp;<button type="button" data-mail='<?php echo $r["cus_mail"]; ?>' class="btn btn-xs btn-danger waves-effect delete"><i class="material-icons">delete</i></button></td></tr>
													<?php
										}
									?>
                                </tbody>
                            </table>
							<span class="col-lg-12 align-center text-center">
								<?php
									if($total_page!=1){
									echo "<a class='m-r-5' href='customer.php?page=".$prev."'><span class='fa fa-angle-left'></a>";
									for($i=1;$i<=$total_page;$i++){
										echo "<a class='btn btn-primary m-l-5' href='customer.php?page=".$i."'>".$i."</a>";
									}
									echo "<a class='m-l-10' href='customer.php?page=".$next."'><span class='fa fa-angle-right'></a>";
									}
								?>
							</span>
                        </div>
                    </div>
                </div>
				<div class="col-md-12">
				<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#addnew-modal">Add New Customer</button>
				</div>

            </div><br><br>

            <!-- #END# Striped Rows -->
        </div>
    </section>
	
	<!-- Default Size -->
            <div class="modal fade" id="defaultModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Edit Customer</h4>
                        </div>
						<form action="cusupdate.php" method="post" enctype="multipart/form-data">
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="name">Customer Name</label>
                                            <input type="text" name="cname" class="form-control" id="tname">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="name">Customer Email</label>
                                            <input type="text" name="cmail" class="form-control" id="tmail"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="name">Mobile #</label>
                                            <input type="text" name="cmob" class="form-control" id="tmob"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="name">Alternative Mobile #</label>
                                            <input type="text" name="camob" class="form-control" id="tamob" />
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line">
										<label class="form-control" id="response"></label>
                                        </div>
                                    </div>
                                </div>
								<div class="col-sm-6">
									<label for="name">Profile Image</label>
                                    <input type="file" name="cfile">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" value="<?php echo $page ?>" name="submit" data->UPDATE</button>
                            <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">CANCEL</button>
                        </div>
						</form>
                    </div>
                </div>
            </div>
	
	<div class="modal fade" id="addnew-modal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
						<form action="addcus.php" method="post">
                        <div class="modal-header">
                            <h4 class="modal-title" id="addnew-modalLabel">Add New Customer</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cname">Customer Name</label>
                                            <input type="text" class="form-control" name="cname" placeholder="Customer name..." />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmail">Customer Email</label>
                                            <input type="text" class="form-control" name="cmail" placeholder="email..." />
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmob">Mobile #</label>
                                            <input type="text" class="form-control" name="cmob" placeholder="mobile number..." />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="camob">Alternative Mobile #</label>
                                            <input type="text" class="form-control" name="camob" placeholder="alternative mobile..." />
                                        </div>
                                    </div>
                                </div>
                            </div>
							
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cgen">Gender</label>
                                        <select class="form-control" name="cgen">
                                        <option value="">-- Please select --</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    	</select>
                                        </div>
                                    </div>
                                </div>
								<div class="col-sm-6">
									<label for="name">Profile Image</label>
                                    <input type="file" name="cfile">
                                </div>
							</div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" name="submit" value="<?php echo $page?>">ADD</button>
                            <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">CANCEL</button>
                        </div>
						</form>
                    </div>
                </div>
            </div>
	<script>
		$(document).ready(function(){
			$(".update").click(function(){
				var name = $(this).data('id');
				$(".modal-body #tname").val(name);
				var email = $(this).data('mail');
				$(".modal-body #tmail").val(email);
				var mob = $(this).data('mob');
				$(".modal-body #tmob").val(mob);
				var amob = $(this).data('amob');
				$(".modal-body #tamob").val(amob);
				var gen = $(this).data('gen');
				$.ajax({
					type: "POST",
					url: '/bpms/dropdowngender.php',
					data: { cgen : gen },
					success: function(data){
						$("#response").html(data);
					}
				})
			});
			$(".delete").click(function(){
				var mail = $(this).data('mail');
				$.ajax({
				type: "POST",
				url: '/bpms/cusdelete.php',
				data: { cmail : mail },
				success: function(html){
					location.reload();
				}
				});
			});
			$("select.cser").change(function(){
				var selectedService = $(".cser option:selected").val();
				$.ajax({
					type: "POST",
					url: '/bpms/Ajax.php',
					data: { service : selectedService },
					success: function(data){
					$("#amtres").val(data);
					}
				});
			});
			var name = '<?php echo $uname ?>';
			$("#logout").click(function(){
				$.ajax({
				type: "POST",
				data: {u_name : name},
				url: '/bpms/insertlogouttime.php',
				success: function(){
				}
				});
			});
		});
	</script>
    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>
	
	<!-- Autosize Plugin Js -->
    <script src="plugins/autosize/autosize.js"></script>
	
	<!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>
	
	<!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
	
	 <!-- Bootstrap Datepicker Plugin Js -->
    <script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
	<script src="js/basic-form-elements.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>

</html>
