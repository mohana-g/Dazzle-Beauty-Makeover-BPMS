<?php
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "bpms";
	$con = mysqli_connect($host,$user,$pass,$db);
?>