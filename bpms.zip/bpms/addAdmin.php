<?php

	$name = $_POST["aname"];
	$mob = $_POST["amob"];
	$mail = $_POST["amail"];
	$password = $_POST["apass"];
	$add = $_POST["aadd"];

	include('connection.php');
	$query = "INSERT INTO `admin`(`a_name`, `a_mob`, `a_mail`, `a_add`, `a_pass`) VALUES ('$name','$mob','$mail','$add','$password')";
	$res = mysqli_query($con,$query);
	if($res){
		header('location:toast.php');
	}
	else{
		header('location:login.html');
	}
?>