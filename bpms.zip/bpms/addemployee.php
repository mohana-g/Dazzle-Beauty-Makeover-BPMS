<?php
	include('connection.php');
	$p = $_POST["submit"];
	$name=$_POST["ename"];
	$email=$_POST["eemail"];
	$mobno=$_POST["emobno"];
	$altermob=$_POST["ealtermob"];
	$spec=$_POST["espec"];
	$sts=$_POST["ests"];
	$query = "INSERT INTO employee(`e_name`, `e_email`, `e_mobno`, `e_altermob`, `e_spec`, `e_status`) VALUES('$name','$email','$mobno','$altermob','$spec','$sts')";
	$res=mysqli_query($con,$query);
	if($res){
		header('location:employee.php?page='.$p.'');
	}
	else{
		echo "Error";
	}
?>