<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Welcome To | Dazzle Beauty Makeover </title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
	
	<link href="fontAwesome/css/all.css" rel="stylesheet" type="text/css">
	<script src="fontAwesome/js/all.js" type="text/javascript"></script>
	<script src="jquery.js" type="text/javascript"></script>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Morris Chart Css-->
    <link href="plugins/morrisjs/morris.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
</head>

<body class="theme-purple">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="index.html">Dazzle Beauty Makeover - Parlour Management</a>
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="info-container">
					<?php 
						$uname = $_SESSION["username"]; 
						include('connection.php');
						$aquery = "SELECT * FROM admin WHERE a_name='$uname'";
						$res = mysqli_query($con,$aquery);
						$ares = mysqli_fetch_assoc($res);
					?>
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $ares["a_name"];?></div>
                    <div class="email"><?php echo $ares["a_mail"];?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a data-toggle="modal" data-target="#addnew-modalp"><i class="material-icons">person</i>Profile</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="login.html" id="logout"><i class="material-icons">input</i>Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </div>
			
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>
                    <li class="active"><a href="home.php"><i class="material-icons">home</i><span>Home</span></a></li>
                    <li><a href="appointments.php"><i class="material-icons">event</i><span>Appointments</span></a></li>
                    <li><a href="services.php"><i class="material-icons">menu</i><span>Services</span></a></li>
                    <li><a href="employee.php"><i class="material-icons">face</i><span>Employee</span></a></li>
					<li><a href="customer.php"><i class="material-icons">people</i><span>Customer</span></a></li>
					<li><a href="#" class="menu-toggle"><i class="material-icons">report</i><span>Reports</span></a>
						<ul class="ml-menu">
						<li><a href="AppointmentsReport.php">Appointments</a></li>
						<li><a href="ServiceReport.php">Services</a></li>	
						<li><a href="EmployeeReport.php">Employees</a></li>	
						<li><a href="CustomerReport.php">Customer</a></li>		
						</ul>
					</li>
                </ul>
            </div>
            <!-- #Menu -->
            
        </aside>
        <!-- #END# Left Sidebar -->
    </section>
			
	
	<div class="modal fade" id="addnew-modalp" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="addnew-modalLabel">Profile</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cname">Name</label>
                                            <input type="text" class="form-control" name="cname" value="<?php echo $ares["a_name"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmail">Email</label>
                                            <input type="text" class="form-control" name="cmail" value="<?php echo $ares["a_mail"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="cmob">Mobile</label>
                                            <input type="text" class="form-control" name="cmob" value="<?php echo $ares["a_mob"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="camob">Address</label>
                                            <input type="text" class="form-control" name="camob" value="<?php echo $ares["a_add"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" name="submit" value="<?php echo $page?>" data-toggle="modal" data-target="#addnew-modalp1">EDIT</button>
                            <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">CANCEL</button>
                        </div>
                    </div>
                </div>
            </div>
	
			<div class="modal fade" id="addnew-modalp1" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
						<form action="updateadmin.php" method="post">
                        <div class="modal-header">
                            <h4 class="modal-title" id="addnew-modalLabel">Edit Profile</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_name">Name</label>
                                            <input type="text" class="form-control" name="a_name" value="<?php echo $ares["a_name"]; ?>" readonly/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_mail">Email</label>
                                            <input type="text" class="form-control" name="a_mail" value="<?php echo $ares["a_mail"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_mob">Mobile</label>
                                            <input type="text" class="form-control" name="a_mob" value="<?php echo $ares["a_mob"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_add">Address</label>
                                            <input type="text" class="form-control" name="a_add" value="<?php echo $ares["a_add"]; ?>"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line"><label for="a_pass">Password</label>
                                            <input type="password" class="form-control" name="a_pass" required/>
                                        </div>
                                    </div>
								</div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect" value="<?php echo $ares["a_pass"]; ?>" name="submit">UPDATE</button>
                            <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">CANCEL</button>
                        </div>
						</form>
                    </div>
                </div>
            </div>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>DASHBOARD</h2>
            </div>

            <!-- Widgets -->
            <div class="row clearfix">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-pink hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">face</i>
                        </div>
                        <div class="content">
                            <div class="text">EMPLOYEES</div>
							<?php
								include('connection.php');
								$query = "SELECT * FROM employee";
								$res = mysqli_query($con,$query);
								$emp_count = mysqli_num_rows($res);
							?>
                            <div class="number"><?php echo $emp_count; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">menu</i>
                        </div>
                        <div class="content">
                            <div class="text">SERVICES</div>
							<?php
								include('connection.php');
								$query = "SELECT * FROM service";
								$res = mysqli_query($con,$query);
								$ser_count = mysqli_num_rows($res);
							?>
                            <div class="number"><?php echo $ser_count; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-light-green hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">store</i>
                        </div>
                        <div class="content">
                            <div class="text">PRODUCTS</div>
							<?php
								include('connection.php');
								$query = "SELECT * FROM service";
								$res = mysqli_query($con,$query);
								$ser_count = mysqli_num_rows($res);
							?>
                            <div class="number"><?php echo $ser_count; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-orange hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">event</i>
                        </div>
                        <div class="content">
                            <div class="text">APPOINTMENTS</div>
							<?php
								include('connection.php');
								$query = "SELECT * FROM cus";
								$res = mysqli_query($con,$query);
								$ap_count = mysqli_num_rows($res);
							?>
                            <div class="number"><?php echo $ap_count; ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Widgets -->
            
            <div class="row clearfix">
                <!-- Task Info -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>Today Appointments</h2>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
								<table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Customer</th>
											<th>Mobile #</th>
                                            <th>Service</th>
                                            <th>Appointment Time</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
									<tbody>
										<?php
											$host = "localhost";
											$dbuser = "root";
											$pass = "";
											$db = "bpms";
											$con = mysqli_connect($host,$dbuser,$pass,$db);
											if(isset($_GET["page"])){
												$page = $_GET["page"];
											}
											else{
												$page = 1;
											}
											$num = 7;
											if($page==1){
												$prev = 1;
											}
											else{
												$prev = $page-1;
											}
											$select = "SELECT * FROM appointment WHERE apt_date = CURRENT_DATE ORDER BY date DESC";
											$res1 = mysqli_query($con,$select);
											$t = mysqli_num_rows($res1);
											$total_page = ceil($t/$num);
											if($page==$total_page){
												$next = $total_page;
											}
											else{
												$next = $page+1;
											}
											$start = ($page-1)*$num;
											$query = "SELECT * FROM appointment WHERE apt_date = CURRENT_DATE ORDER BY date DESC limit $start,$num";
											$res = mysqli_query($con,$query);
											$var=(($page-1)*$num);
											while($r = mysqli_fetch_assoc($res)){
												$ser = $r["cus_ser"];
												$q = "SELECT * FROM service WHERE ser_name='$ser'";
												$result = mysqli_query($con,$q);
												$rows = mysqli_fetch_assoc($result);
												$ser_color = $rows["ser_color"];
												$apt_name = $r["cus_name"];
												$q1 = "SELECT cus_mob FROM cus WHERE cus_name = '$apt_name'";
												$result1 = mysqli_query($con,$q1);
												$rows1 = mysqli_fetch_assoc($result1);
												$var++;
												$dis= '<tr><td>'.$var.'</td>
														<td>'.$r["cus_name"].'</td>
														<td>'.$rows1["cus_mob"].'</td>
														<td><span class="label" style="background-color:'.$ser_color.'">'.$r["cus_ser"].'</span></td>
														<td>'.$r["apt_time"].'</td>
														<td>'.$r["amt"].'</td></tr>';
												echo $dis;
												}											
										?>
                                    </tbody>
                                </table>
								<span class="col-lg-12 align-center text-center">
								<?php 
									if($total_page!=1){
									echo "<a class='m-r-5' href='home.php?page=".$prev."'><span class='fa fa-angle-left'></span></a>";
									for($i=1;$i<=$total_page;$i++){
										echo "<a class='btn btn-primary m-l-5' href='home.php?page=".$i."'>".$i."</a>";
									}
									echo "<a class='m-l-10' href='home.php?page=".$next."'><span class='fa fa-angle-right'></span></a>";
									}
								?>
								</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- #END# Task Info -->
            </div>
        </div>
    </section>
	<script>
		$(document).ready(function(){
			var name = '<?php echo $uname ?>';
			$("#logout").click(function(){
				$.ajax({
				type: "POST",
				data: {u_name : name},
				url: '/bpms/insertlogouttime.php',
				success: function(){
				}
				});
			});
		})
	</script>

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="plugins/jquery-countto/jquery.countTo.js"></script>

    <!-- Morris Plugin Js -->
    <script src="plugins/raphael/raphael.min.js"></script>
    <script src="plugins/morrisjs/morris.js"></script>

    <!-- ChartJs -->
    <script src="plugins/chartjs/Chart.bundle.js"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="plugins/flot-charts/jquery.flot.js"></script>
    <script src="plugins/flot-charts/jquery.flot.resize.js"></script>
    <script src="plugins/flot-charts/jquery.flot.pie.js"></script>
    <script src="plugins/flot-charts/jquery.flot.categories.js"></script>
    <script src="plugins/flot-charts/jquery.flot.time.js"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="plugins/jquery-sparkline/jquery.sparkline.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/index.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>

</html>
