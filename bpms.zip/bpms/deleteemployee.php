<?php 
	include('connection.php');
	$name = $_POST['ename'];
	$query = "DELETE FROM employee WHERE e_name ='$name' ";
	$res = mysqli_query($con,$query);
?>